#!/usr/bin/env python3
from pathlib import Path
import shutil,subprocess,plistlib
root=Path(__file__).resolve().parents[1]
source=root/'build/AirportBZ-Sequoia/AirportItlwm'
assert source.is_file()
out=root/'build/Rebuilt/AirportBZ-Sequoia.kext'
assert not out.exists(),'Refuse to overwrite a previous rebuild'
(out/'Contents/MacOS').mkdir(parents=True)
shutil.copyfile(source,out/'Contents/MacOS/AirportItlwm')
(out/'Contents/MacOS/AirportItlwm').chmod(0o755)
shutil.copyfile(root/'Driver/AirportBZ-Sequoia.kext/Contents/Info.plist',out/'Contents/Info.plist')
subprocess.run(['/usr/bin/codesign','--force','--sign','-','--timestamp=none',str(out)],check=True)
subprocess.run(['/usr/bin/codesign','--verify','--strict',str(out)],check=True)
print(out)
