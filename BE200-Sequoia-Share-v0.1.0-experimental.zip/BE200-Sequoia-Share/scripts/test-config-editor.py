#!/usr/bin/env python3
"""Offline tests. Does not access or mount the real EFI."""
from pathlib import Path
import copy,json,plistlib,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
guid='7C436110-AB2A-4BBB-A880-FE41995C9F82'
with tempfile.TemporaryDirectory(prefix='airportbz-config-test-') as temp:
 t=Path(temp);k=t/'Kexts';k.mkdir()
 alias=k/'CustomIntel.kext/Contents';alias.mkdir(parents=True)
 (alias/'Info.plist').write_bytes(plistlib.dumps({'CFBundleIdentifier':'com.zxystd.AirportItlwm'}))
 diag=k/'CustomProbe.kext/Contents';diag.mkdir(parents=True)
 (diag/'Info.plist').write_bytes(plistlib.dumps({'CFBundleIdentifier':'local.be200.FirmwareDiagnostic'}))
 sample={'ACPI':{'Add':[{'Path':'SSDT-TOUCHPAD.aml','Enabled':True}]},'UEFI':{},
  'Kernel':{'Add':[{'BundlePath':'IOSkywalkFamily.kext','Enabled':True},{'BundlePath':'IO80211FamilyLegacy.kext/Contents/PlugIns/AirPortBrcmNIC.kext','Enabled':True},{'BundlePath':'CustomIntel.kext','Enabled':True},{'BundlePath':'Lilu.kext','Enabled':True},{'BundlePath':'BE200FirmwareDiagnostic65.kext','Enabled':True},{'BundlePath':'CustomProbe.kext','Enabled':True}],
   'Block':[{'Identifier':'com.apple.iokit.IOSkywalkFamily','Enabled':True},{'Identifier':'com.apple.iokit.IO80211Family','Enabled':True},{'Identifier':'com.apple.iokit.IONDRVSupport','Enabled':True}],
   'Emulate':{'Cpuid1Data':bytes.fromhex('55060a00000000000000000000000000')}},
  'NVRAM':{'Add':{guid:{'boot-args':'-v custom="quoted value" itlwm_he=1 text=abc\'def','csr-active-config':b'\x03\x08\x00\x00'}}},
  'PlatformInfo':{'Generic':{'SystemSerialNumber':'SYNTHETIC-TEST-ONLY'}}}
 src=t/'input.plist';out=t/'output.plist';src.write_bytes(plistlib.dumps(sample,fmt=plistlib.FMT_BINARY))
 def patch(a,b):
  return subprocess.run(['/usr/bin/osascript','-l','JavaScript',str(root/'scripts/patch-config.js'),str(a),str(b),str(k)],capture_output=True,text=True)
 p=patch(src,out);assert p.returncode==0,p.stderr
 d=plistlib.loads(out.read_bytes());assert d['ACPI']==sample['ACPI'] and d['PlatformInfo']==sample['PlatformInfo']
 assert d['Kernel']['Emulate']==sample['Kernel']['Emulate']
 assert [x['Enabled'] for x in d['Kernel']['Add'][:4]]==[False,False,False,True]
 assert [x['Enabled'] for x in d['Kernel']['Add'][4:6]]==[False,False]
 assert [x['Enabled'] for x in d['Kernel']['Block']]==[False,False,True]
 assert d['NVRAM']['Add'][guid]['boot-args']==sample['NVRAM']['Add'][guid]['boot-args'].replace(' itlwm_he=1','')
 assert d['NVRAM']['Add'][guid]['csr-active-config']==b'\x03\x08\x00\x00'
 assert d['NVRAM']['Delete'][guid]==['boot-args']
 again=t/'again.plist';p=patch(out,again);assert p.returncode==0,p.stderr
 assert plistlib.loads(again.read_bytes())==d,'Repeated install must not add duplicate entries'
 bad=t/'bad.plist';bad.write_bytes(plistlib.dumps({'SomethingElse':True}));badout=t/'bad-output.plist'
 p=patch(bad,badout);assert p.returncode!=0 and not badout.exists()
 print(json.dumps({'binary_plist_and_data_preserved':True,'only_wifi_settings_changed':True,'aliased_driver_detected':True,'repeat_install_idempotent':True,'invalid_config_refused':True},indent=2))
