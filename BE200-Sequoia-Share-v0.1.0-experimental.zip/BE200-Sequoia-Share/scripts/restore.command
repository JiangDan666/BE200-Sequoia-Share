#!/bin/zsh
set -eu
share_dir=${0:A:h}
/usr/bin/osascript - "$share_dir/rollback-root.sh" <<'APPLESCRIPT'
on run argv
    do shell script ("/bin/zsh " & quoted form of item 1 of argv) with administrator privileges
end run
APPLESCRIPT
print '本次安装涉及的配置和驱动已回退，请手动重启。'
read '?按回车关闭。'
