/* SPDX-License-Identifier: GPL-2.0-only */
ObjC.import('Foundation');
function run(argv) {
    if (argv.length !== 3) throw new Error('Expected input config, output config, Kexts directory');
    var error = $();
    function load(path, mutable) {
        var data = $.NSData.dataWithContentsOfFile($(path));
        if (!data || data.isNil()) throw new Error('Cannot read plist');
        var p = $.NSPropertyListSerialization.propertyListWithDataOptionsFormatError(data, mutable ? 1 : 0, null, error);
        if (!p || p.isNil()) throw new Error('Cannot parse plist');
        return p;
    }
    function get(d,k) { var v=d.objectForKey($(k)); return (!v || v.isNil()) ? null : v; }
    function str(v) { return v === null ? '' : String(ObjC.unwrap(v)); }
    function set(d,k,v) { d.setObjectForKey(v,$(k)); }
    function guidKey(d,want) {
        var keys=d.allKeys;
        for(var i=0;i<keys.count;i++){var k=str(keys.objectAtIndex(i));if(k.toUpperCase()===want)return k;}
        return want;
    }
    var root=load(argv[0],true),kernel=get(root,'Kernel');
    if(!kernel || !get(root,'ACPI') || !get(root,'UEFI')) throw new Error('Not an OpenCore config');
    var add=get(kernel,'Add');
    if(!add || !add.isKindOfClass($.NSMutableArray)) throw new Error('Kernel/Add is not a mutable array');
    var selected=null,disabled=0;
    for(var i=0;i<add.count;i++) {
        var item=add.objectAtIndex(i),path=str(get(item,'BundlePath'));
        if(path==='AirportBZ-Sequoia.kext' && selected===null) {selected=item;continue;}
        var old=/^(AirportItlwm[^/]*\.kext|itlwm\.kext|IOSkywalkFamily\.kext|IO80211FamilyLegacy\.kext|BE200FirmwareDiagnostic[^/]*\.kext)(\/|$)/i.test(path);
        var infoPath=argv[2]+'/'+path+'/Contents/Info.plist';
        if($.NSFileManager.defaultManager.fileExistsAtPath($(infoPath))) {
            var ident=str(get(load(infoPath,false),'CFBundleIdentifier'));
            if(['com.zxystd.AirportItlwm','com.zxystd.itlwm','com.apple.iokit.IO80211FamilyLegacy','com.apple.iokit.IOSkywalkFamily','local.be200.FirmwareDiagnostic'].indexOf(ident)!==-1)old=true;
        }
        if(path==='AirportBZ-Sequoia.kext')old=true;
        if(old) {set(item,'Enabled',$.NSNumber.numberWithBool(false));disabled++;}
    }
    if(selected===null){selected=$.NSMutableDictionary.alloc.init;add.addObject(selected);}
    var strings={Arch:'x86_64',BundlePath:'AirportBZ-Sequoia.kext',Comment:'AirportBZ 0ccab16 Sequoia BE200 community test build',ExecutablePath:'Contents/MacOS/AirportItlwm',PlistPath:'Contents/Info.plist',MinKernel:'24.2.0',MaxKernel:'24.99.99'};
    Object.keys(strings).forEach(function(k){set(selected,k,$(strings[k]));});
    set(selected,'Enabled',$.NSNumber.numberWithBool(true));
    var blocks=get(kernel,'Block'),unblocked=0;
    if(blocks)for(var j=0;j<blocks.count;j++){
        var block=blocks.objectAtIndex(j),identifier=str(get(block,'Identifier'));
        if(identifier==='com.apple.iokit.IOSkywalkFamily' || identifier==='com.apple.iokit.IO80211Family'){
            set(block,'Enabled',$.NSNumber.numberWithBool(false));unblocked++;
        }
    }
    var nvram=get(root,'NVRAM'),removedHE=false;
    if(nvram){
        var nvadd=get(nvram,'Add'),guid='7C436110-AB2A-4BBB-A880-FE41995C9F82';
        if(nvadd){
            var parameters=get(nvadd,guidKey(nvadd,guid));
            if(parameters){
                var args=str(get(parameters,'boot-args'));
                var cleaned=args.replace(/(^|\s)itlwm_he=\S+/g,'');
                if(cleaned!==args){
                    removedHE=true;set(parameters,'boot-args',$(cleaned));
                    var deletes=get(nvram,'Delete');
                    if(!deletes){deletes=$.NSMutableDictionary.alloc.init;set(nvram,'Delete',deletes);}
                    var dk=guidKey(deletes,guid),values=get(deletes,dk);
                    if(!values){values=$.NSMutableArray.alloc.init;set(deletes,dk,values);}
                    if(!values.containsObject($('boot-args')))values.addObject($('boot-args'));
                }
            }
        }
    }
    var data=$.NSPropertyListSerialization.dataWithPropertyListFormatOptionsError(root,100,0,error);
    if(!data || data.isNil() || !data.writeToFileAtomically($(argv[1]),true)) throw new Error('Cannot write candidate config');
    return JSON.stringify({disabledEntries:disabled,unblockedEntries:unblocked,experimentalHERemoved:removedHE});
}
