#!/usr/bin/env python3
"""Compile a pinned AirportBZ source on this Mac. No loading or deployment."""
from pathlib import Path
import concurrent.futures,subprocess,re,json,hashlib,datetime,plistlib,os
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'Source/AirportBZ'
SDK=Path(os.environ['MAC_KERNEL_SDK']).resolve()
subprocess.run(['/bin/sh',str(SRC/'scripts/prepare-mackernelsdk.sh'),str(SDK)],check=True)
OUT=ROOT/'build/AirportBZ-Sequoia'
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'objects').mkdir(exist_ok=True)
(OUT/'logs').mkdir(exist_ok=True)
commit=(ROOT/'SOURCE_COMMIT.txt').read_text().strip()
assert commit=='0ccab1627764406861fb9eb0a06ca36e31b4440f'
project=(SRC/'itlwm.xcodeproj/project.pbxproj').read_text()
phase=re.search(r'AFFBDFD057C2402C908ECB89 /\* Sources \*/ = \{(.*?)\n\t\t\};',project,re.S).group(1)
inventory={}
for path in SRC.rglob('*'):
 if path.is_file() and '.git' not in path.parts:inventory.setdefault(path.name,[]).append(path)
sources=[]
for name in re.findall(r'[A-F0-9]{24} /\* (.*?) in Sources \*/',phase):
 if name=='(null)':continue
 matches=inventory.get(name,[])
 assert len(matches)==1,(name,matches)
 sources.append(matches[0])
assert len(sources)==57
clang='/Library/Developer/CommandLineTools/usr/bin/clang++'
resource=subprocess.check_output([clang,'-print-resource-dir'],text=True).strip()
common=['-target','x86_64-apple-macos15.2','-mkernel','-fapple-kext','-fno-sized-deallocation','-fno-use-cxa-atexit','-fstack-protector','-fno-common','-fno-builtin','-mno-red-zone','-mcmodel=kernel','-nostdinc','-D__PRIVATE_SPI__','-DKERNEL','-DKERNEL_PRIVATE','-DDRIVER_PRIVATE','-DIEEE80211_STA_ONLY','-DAIRPORT','-DAIRPORT_WCL','-DAIRPORT_VTD','-DIO80211FAMILY_V2','-D__IO80211_TARGET=150200','-DITLWM_VERSION="1.0.0"','-DGIT_COMMIT="0ccab16-local-mac"','-isystem',str(SDK/'Headers'),'-isystem',resource+'/include']
for path in ['.','itlwm','itlwm/hal_iwx','itl80211','itl80211/openbsd','itl80211/linux','include','include/Airport','AirportItlwm']:
 common+=['-I',str(SRC/path)]
common+=['-include',str(SRC/'itlwm/PrivateSPI.pch'),'-O1','-Wno-deprecated-register','-Wno-multichar','-Werror=return-type','-x','c++','-std=gnu++14','-fno-exceptions','-fno-rtti']
commands=[]
for index,source in enumerate(sources):
 obj=OUT/'objects'/('%02d-'%index+source.stem+'.o')
 commands.append({'source':str(source.relative_to(SRC)),'directory':str(SRC),'file':str(source),'arguments':[clang,*common,'-c',str(source),'-o',str(obj)],'object':str(obj),'log':str(OUT/'logs'/(obj.name+'.log'))})
(OUT/'compile_commands.json').write_text(json.dumps(commands,indent=2)+'\n')
def compile_one(c):
 with open(c['log'],'w') as log:r=subprocess.run(c['arguments'],cwd=SRC,stdout=log,stderr=subprocess.STDOUT)
 return {'source':c['source'],'returncode':r.returncode,'log':c['log']}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(compile_one,commands))
report={'time':datetime.datetime.now().astimezone().isoformat(),'source_commit':commit,'sdk_commit':'3f750085caa17ec3a7880f11c11bf4f48cd6a164','source_count':len(commands),'compile_results':results,'pass':all(r['returncode']==0 for r in results),'installed':False,'hardware_tested':False,'adaptation':'Apple clang 17: omit LLVM21-only disable-atexit-based-global-dtor-lowering option; native ld. Review initializer sections before any deployment.'}
(OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
failed=[r for r in results if r['returncode']]
if failed:
 for r in failed[:4]:print(r['source']);print(Path(r['log']).read_text()[-3500:])
 print('Failed',len(failed),'of',len(results));raise SystemExit(1)
module=OUT/'module.cpp'
module.write_text("""#include <mach/mach_types.h>
extern "C" {
extern kern_return_t _start(kmod_info_t *, void *);
extern kern_return_t _stop(kmod_info_t *, void *);
KMOD_EXPLICIT_DECL(com.zxystd.AirportItlwm, "1.0.0", _start, _stop)
__private_extern__ kmod_start_func_t *_realmain = 0;
__private_extern__ kmod_stop_func_t *_antimain = 0;
__private_extern__ int _kext_apple_cc = 1;
}
""")
subprocess.run([clang,*common,'-c',str(module),'-o',str(OUT/'objects/module.o')],check=True,cwd=SRC)
link=['/Library/Developer/CommandLineTools/usr/bin/ld','-arch','x86_64','-kext','-undefined','dynamic_lookup','-macosx_version_min','15.2','-o',str(OUT/'AirportItlwm')]+[c['object'] for c in commands]+[str(OUT/'objects/module.o'),str(SDK/'Library/x86_64/libkmod.a')]
linked=subprocess.run(link,capture_output=True,text=True)
(OUT/'link.log').write_text(linked.stdout+linked.stderr)
report['link_returncode']=linked.returncode;report['pass']=linked.returncode==0
if linked.returncode==0:report['binary_sha256']=hashlib.sha256((OUT/'AirportItlwm').read_bytes()).hexdigest()
(OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='compile_results'},indent=2))
if linked.returncode:print(linked.stderr);raise SystemExit(1)
