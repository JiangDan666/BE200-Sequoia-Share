#!/bin/zsh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
share_root=${0:A:h}
print 'AirportBZ / BE200 原生 Sequoia 实测候选版'
print '适用于 x86_64 macOS 15.2–15.x 和受支持的 BE200/BE201。'
print '会备份完整 EFI、停用冲突无线加载项并安装新驱动；不撤销系统根补丁，不改显卡或电源设置。'
print '请先阅读“先读我-安装与回退.md”，确认系统无线框架为原生版本。'
/usr/sbin/diskutil list physical
read 'share_disk?请输入实际启动 OpenCore 所在的 ESP 编号（如 disk0s1，输入其他内容可退出）：'
[[ $share_disk =~ '^disk[0-9]+s[0-9]+$' ]] || exit 1
/usr/bin/osascript - "$share_root/scripts/install-root.sh" "$share_disk" "$HOME/Desktop" "$(/usr/bin/id -u)" <<'APPLESCRIPT'
on run argv
    set commandText to "/bin/zsh " & quoted form of item 1 of argv & " " & quoted form of item 2 of argv & " " & quoted form of item 3 of argv & " " & quoted form of item 4 of argv
    do shell script commandText with administrator privileges
end run
APPLESCRIPT
print '写入完成。请核对桌面的 EFI 备份后手动重启，再在系统 Wi-Fi 中扫描和连接。'
read '?按回车关闭。'
