#!/bin/zsh
print '此窗口运行时临时阻止空闲睡眠，屏幕仍可关闭或锁定。'
print '建议接电、不合盖；不保证覆盖手动睡眠、合盖或低电量保护。'
print '下载结束后按 Control+C 或关闭本窗口即可恢复通常行为，不会修改 pmset 设置。'
/usr/bin/caffeinate -i -s
